package tests;
import org.testng.annotations.Test;

public class SpeedTestTest extends BaseTest {

    @Test
    public void test(){
        openHomePage()
                .clickOnGoButton()
                .iWaitToPageIsLoad()
                .getDownloadSpeedResult()
                .getUploadSpeedResult()
                .getPingResult()
                .getJitterResult()
                .getLossResult();
    }
}
