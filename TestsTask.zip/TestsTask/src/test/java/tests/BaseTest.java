package tests;

import com.codeborne.selenide.WebDriverRunner;
import static driver.driver_factory.DriverFactory.getDriverFactory;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import page_steps.impl.speed_menu_page_steps.home_page_steps.HomePageSteps;

abstract class BaseTest {
    private WebDriver driver;
    private HomePageSteps homePageSteps;

    @BeforeTest
    @Parameters("driverName")
    public void setDriver(String driverName){
        try {
           driver = getDriverFactory().getDriver(driverName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        WebDriverRunner.setWebDriver(driver);
    }


    @AfterMethod(alwaysRun =  true)
    public void resetDriver(){
        ((AndroidDriver) WebDriverRunner.getWebDriver()).resetApp();
        ((AndroidDriver) WebDriverRunner.getWebDriver()).closeApp();
    }

    public HomePageSteps openHomePage(){
        homePageSteps = new HomePageSteps();
        return homePageSteps.iWaitToPageIsLoad();
    }
}
