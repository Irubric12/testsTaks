package page_object.speed_menu.test_result;

import org.openqa.selenium.By;

public class ResultPage {
    private By feedback = By.id("org.zwanoo.android.speedtest:id/suite_completed_feedback_assembly");

    private By downloadSpeed = By.xpath("//android.widget.FrameLayout[@content-desc = 'DOWNLOAD']" +
            "//android.widget.TextView[@resource-id = 'org.zwanoo.android.speedtest:id/txt_test_result_value']");

    private By uploadSpeed = By.xpath("//android.widget.FrameLayout[@content-desc = 'UPLOAD']" +
            "//android.widget.TextView[@resource-id = 'org.zwanoo.android.speedtest:id/txt_test_result_value']");

    private By ping = By.xpath("//android.view.ViewGroup[@content-desc = 'Ping']" +
            "//android.widget.TextView[@resource-id = 'org.zwanoo.android.speedtest:id/txt_test_result_value']");

    private By jitter = By.xpath("//android.view.ViewGroup[@content-desc = 'Jitter']" +
            "//android.widget.TextView[@resource-id = 'org.zwanoo.android.speedtest:id/txt_test_result_value']");

    private By loss = By.xpath("//android.view.ViewGroup[@resource-id = 'org.zwanoo.android.speedtest:id/test_result_item_packet_loss']" +
            "//android.widget.TextView[@resource-id = 'org.zwanoo.android.speedtest:id/txt_test_result_value']");


    public By getFeedback() {
        return feedback;
    }

    public By getDownloadSpeed() {
        return downloadSpeed;
    }

    public By getUploadSpeed() {
        return uploadSpeed;
    }

    public By getPing() {
        return ping;
    }

    public By getJitter() {
        return jitter;
    }

    public By getLoss() {
        return loss;
    }
}
