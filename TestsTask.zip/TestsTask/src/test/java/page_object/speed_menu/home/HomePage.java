package page_object.speed_menu.home;

import org.openqa.selenium.By;

public class HomePage {
    private By goButton = By.id("org.zwanoo.android.speedtest:id/go_button");
    private By hostAssemblyWidgets = By.id("org.zwanoo.android.speedtest:id/host_assembly_item_connections");

    public By getGoButton() {
        return goButton;
    }

    public By getHostAssemblyWidgets() {
        return hostAssemblyWidgets;
    }
}
