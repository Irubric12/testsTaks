package page_object;

public interface IWait {
    <T> T  iWaitToPageIsLoad();
}
