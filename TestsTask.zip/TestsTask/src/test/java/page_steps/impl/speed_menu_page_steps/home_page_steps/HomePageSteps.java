package page_steps.impl.speed_menu_page_steps.home_page_steps;

import static element_finder.Finder.find;

import com.codeborne.selenide.Condition;
import page_object.speed_menu.home.HomePage;
import page_steps.PageSteps;
import page_steps.impl.speed_menu_page_steps.result_page_steps.ResultPageSteps;

public class HomePageSteps extends PageSteps {
    private HomePage homePage = new HomePage();

    @Override
    public HomePageSteps iWaitToPageIsLoad() {
        find(homePage.getHostAssemblyWidgets()).waitUntil(Condition.visible, 1000000);
        return this;
    }

    public ResultPageSteps clickOnGoButton(){
        find(homePage.getGoButton()).waitUntil(Condition.visible, 1000000).click();
        return new ResultPageSteps();
    }
}
