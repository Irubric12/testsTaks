package page_steps.impl.speed_menu_page_steps.result_page_steps;

import static element_finder.Finder.find;

import com.codeborne.selenide.Condition;
import page_object.speed_menu.test_result.ResultPage;
import page_steps.PageSteps;

public class ResultPageSteps extends PageSteps {
    private ResultPage resultPage = new ResultPage();

    @Override
    public ResultPageSteps iWaitToPageIsLoad() {
        find(resultPage.getFeedback()).waitUntil(Condition.visible, 250000);
        return this;
    }

    public ResultPageSteps getDownloadSpeedResult(){
        String downloadSpeed = find(resultPage.getDownloadSpeed()).waitUntil(Condition.visible, 10000).getText();
        System.out.println("Download Speed is " + downloadSpeed + " Mbps");

        return this;
    }

    public ResultPageSteps getUploadSpeedResult(){
        String uploadSpeed = find(resultPage.getUploadSpeed()).waitUntil(Condition.visible, 10000).getText();
        System.out.println("Upload Speed is " + uploadSpeed + " Mbps");

        return this;
    }

    public ResultPageSteps getPingResult(){
        String ping = find(resultPage.getPing()).waitUntil(Condition.visible, 10000).getText();
        System.out.println("Ping is " + ping);

        return this;
    }

    public ResultPageSteps getJitterResult(){
        String jitter = find(resultPage.getJitter()).waitUntil(Condition.visible, 10000).getText();
        System.out.println("Jitter is " + jitter);

        return this;
    }

    public ResultPageSteps getLossResult(){
        String loss = find(resultPage.getLoss()).waitUntil(Condition.visible, 10000).getText();
        System.out.println("Loss is " + loss);

        return this;
    }
}
