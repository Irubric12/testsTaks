package page_steps;

import com.codeborne.selenide.WebDriverRunner;
import io.appium.java_client.android.AndroidDriver;
import page_object.IWait;

public abstract class PageSteps implements IWait {
    AndroidDriver driver = (AndroidDriver) WebDriverRunner.getWebDriver();
}
