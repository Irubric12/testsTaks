package global_variables;

import java.io.File;

public class Paths {
    public static final String CAPABILITY_PATH = "./src/main/resources/capability.json";

    static File file = new File("./src/main/resources/app/speedtest.apk");
    public static final String PATH_TO_APK_FILE = file.getAbsolutePath();
}
