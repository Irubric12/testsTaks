package element_finder;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;

public class Finder {
    public static SelenideElement find(By bySelector){
        return Selenide.$(bySelector);
    }
}
