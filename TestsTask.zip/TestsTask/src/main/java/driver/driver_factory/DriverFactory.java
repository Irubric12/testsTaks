package driver.driver_factory;

import static driver.local_driver.LocalDriverProvider.getLocalDriverProvider;
import org.openqa.selenium.WebDriver;

public class DriverFactory {
    private static DriverFactory driverFactory;

    private DriverFactory(){

    }

    public static DriverFactory getDriverFactory(){
        if (driverFactory == null){
            driverFactory = new DriverFactory();
        }
        return driverFactory;
    }

    public WebDriver getDriver(String driverName) throws Exception {
        getLocalDriverProvider();

        switch (driverName){
            case "local":
                return getLocalDriverProvider().androidDriver();
            default: throw new Exception("driver not found");
        }
    }
}
