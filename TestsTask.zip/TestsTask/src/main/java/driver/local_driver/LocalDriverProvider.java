package driver.local_driver;

import capability.provider.CapabilityProvider;
import com.codeborne.selenide.SelenideElement;
import io.appium.java_client.android.AndroidDriver;

import java.net.MalformedURLException;
import java.net.URL;

public class LocalDriverProvider {
    private URL url;
    private CapabilityProvider capabilityProvider;
    private static LocalDriverProvider localDriverProvider;

    private LocalDriverProvider(){

    }

    public static LocalDriverProvider getLocalDriverProvider(){
        if (localDriverProvider == null){
            localDriverProvider = new LocalDriverProvider();
        }
        return localDriverProvider;
    }


    public AndroidDriver androidDriver(){
        capabilityProvider = new CapabilityProvider();

        try {
            url = new URL("http://0.0.0.0:4723/wd/hub");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return new AndroidDriver<SelenideElement>(
                url, capabilityProvider.getAndroidCapability());
    }
}
