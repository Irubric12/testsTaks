package capability.provider;

import capability.parser.CapabilityModelParser;
import static global_variables.Paths.PATH_TO_APK_FILE;
import org.openqa.selenium.remote.DesiredCapabilities;

import static io.appium.java_client.remote.AndroidMobileCapabilityType.*;
import static io.appium.java_client.remote.MobileCapabilityType.*;
import static org.openqa.selenium.remote.CapabilityType.PLATFORM_NAME;

public class CapabilityProvider {
    private CapabilityModelParser capabilityModel;
    private DesiredCapabilities capabilities;

    public DesiredCapabilities getAndroidCapability(){
        capabilities = new DesiredCapabilities();
        capabilityModel = new CapabilityModelParser();

        capabilities.setCapability(DEVICE_NAME, capabilityModel.getCapabilities().getDeviceName());
        capabilities.setCapability(AUTOMATION_NAME, capabilityModel.getCapabilities().getAutomationName());

        capabilities.setCapability(PLATFORM_NAME, capabilityModel.getCapabilities().getPlatformName());
        capabilities.setCapability(PLATFORM_VERSION, capabilityModel.getCapabilities().getPlatformVersion());

        capabilities.setCapability(APP, PATH_TO_APK_FILE);
        capabilities.setCapability(APP_PACKAGE, capabilityModel.getCapabilities().getAppPackage());

        capabilities.setCapability(APP_ACTIVITY, capabilityModel.getCapabilities().getAppActivity());
        capabilities.setCapability(AUTO_GRANT_PERMISSIONS, capabilityModel.getCapabilities().isAutoGrantPermission());

        capabilities.setCapability("screenOrientation", "portrait");

        return capabilities;
    }
}
