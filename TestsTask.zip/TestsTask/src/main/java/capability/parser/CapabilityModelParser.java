package capability.parser;

import capability.model.CapabilityModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import global_variables.Paths;

import java.io.File;
import java.io.IOException;

public class CapabilityModelParser {
    private ObjectMapper objectMapper;
    private File file;
    private CapabilityModel capabilityModel ;

    public CapabilityModel getCapabilities(){
        objectMapper = new ObjectMapper();
        file = new File(Paths.CAPABILITY_PATH);
        capabilityModel = new CapabilityModel();

        try {
            capabilityModel = objectMapper.readValue(file, CapabilityModel.class);
        } catch (IOException e) {
            System.out.println("I can't parse the file");
            e.printStackTrace();
        }

        return capabilityModel;
    }
}
