package capability.model;

public class CapabilityModel {
    private String deviceName;
    private String automationName;
    private String platformName;
    private int platformVersion;
    private String appPackage;
    private String appActivity;
    private boolean autoGrantPermission;
    private String app;

    public String getDeviceName() {
        return deviceName;
    }

    public String getAutomationName() {
        return automationName;
    }

    public String getPlatformName() {
        return platformName;
    }

    public int getPlatformVersion() {
        return platformVersion;
    }

    public String getAppPackage() {
        return appPackage;
    }

    public String getAppActivity() {
        return appActivity;
    }

    public boolean isAutoGrantPermission() {
        return autoGrantPermission;
    }

    public String getApp() {
        return app;
    }
}
